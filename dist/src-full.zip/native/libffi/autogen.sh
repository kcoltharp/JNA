#!/bin/sh
exec autoreconf -v -f -i